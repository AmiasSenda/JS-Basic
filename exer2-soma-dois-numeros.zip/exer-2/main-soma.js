var n1 =Number(prompt("Insira o primeiro número: "))
var n2 = Number(prompt("Insira o segundo número: "))
var soma = Number(n1 + n2)


alert("Resultado: "+soma)