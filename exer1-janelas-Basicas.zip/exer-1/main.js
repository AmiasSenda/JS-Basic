alert("Olá Mundo!")
confirm("Está gostando desta experiência ?")